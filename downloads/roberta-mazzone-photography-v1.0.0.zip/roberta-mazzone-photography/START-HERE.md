# 自然光旅行摄影：上传使用 · v1.0.0

1. 将本 ZIP 和照片一起上传给支持解压、文件读取与图像生成/编辑的 Agent。
2. 复制以下指令：

> 请解压技能包，读取 roberta-mazzone-photography/SKILL.md 及其要求的参考文件，按规则处理我上传的照片。任务：用 edit 模式处理这一张照片，轻微暖色、保护高光、保留真实材质及人物身份和场景结构，不新增或移动物体；请生成修图预览。

若无法解压，请本地解压后上传完整文件夹（平台支持时）。无法读取文件时，请让 Agent 明确告知；没有图像工具时，可先输出提示词或修图方案。
附件不一定会安装为长期技能。安装时将整个 roberta-mazzone-photography 文件夹放到平台规定的 Skill 目录，保留相对路径。
本包保留技能源文件、来源和许可；如含 LICENSE / SOURCE.md，使用和分享时请遵守并保留。源仓库：https://github.com/RickyyyFu/photo-editing-skills
